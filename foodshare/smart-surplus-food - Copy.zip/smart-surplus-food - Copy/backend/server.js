const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const connectDB = require("./config/db");
const cron = require("node-cron");
const path = require("path"); // ✅ Added for serving static files
const FoodItem = require("./models/FoodItem");
const { init } = require("./utils/sendNotification");

dotenv.config();
connectDB();

const app = express();
app.use(cors());
app.use(helmet());
app.use(express.json());
app.use("/uploads", express.static("uploads"));
app.use(rateLimit({ windowMs: 60 * 1000, max: 100 }));

// ✅ Serve uploaded images so frontend can access them
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/food", require("./routes/foodRoutes"));
app.use("/api/analytics", require("./routes/analyticsRoutes"));
app.use("/api/events", require("./routes/eventRoutes"));

// Auto-remove expired food every hour
cron.schedule("0 * * * *", async () => {
  await FoodItem.deleteMany({ availableUntil: { $lt: new Date() } });
  console.log("🗑️ Removed expired food items");
});

const server = app.listen(process.env.PORT || 5000, () => {
  console.log(`🚀 Server running on port ${process.env.PORT || 5000}`);
});

init(server);
